Petricore Agar Colony Dataset

Class 0 = colony
Each JPG has a matching YOLO TXT label.
Split: 80% train / 10% validation / 10% test.
Agar type is stored in metadata.json and the filename, while the detector learns one class: colony.
